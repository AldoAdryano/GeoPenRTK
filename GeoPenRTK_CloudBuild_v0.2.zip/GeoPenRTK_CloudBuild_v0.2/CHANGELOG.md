# Changelog

## 0.2.0-cloud-build
- Menambahkan GitHub Actions untuk menghasilkan APK tanpa Android Studio.
- Menyetel AGP 8.13.2, Gradle 8.13, JDK 17, dan Kotlin 2.2.21.
- Menambahkan dependency AndroidX Core.
- Menambahkan panduan build dan instalasi dari POCO/Android.

## 0.1.0-mvp
- Bluetooth Classic SPP, parser NMEA, NTRIP client, command mode, titik base, dan averaging dasar.
