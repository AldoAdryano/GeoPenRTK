# GeoPen RTK — Android MVP

Aplikasi Android native (Kotlin + Jetpack Compose) untuk receiver Unicorn/EGNSS GeoPen Hexa.

## Fungsi yang sudah dibuat

- koneksi Bluetooth Classic SPP ke perangkat paired seperti `EGNSS 757`;
- pembacaan NMEA `GGA`, `RMC`, `GSA`, `GSV`, dan `GST`;
- status otomatis `Single`, `DGPS`, `RTK Float`, dan `RTK Fix`;
- NTRIP Client: Host, Port, Mountpoint, Username, Password, dan interval GGA;
- pengiriman GGA live ke NTRIP caster;
- penerimaan RTCM biner dari caster dan penerusan ke GeoPen lewat Bluetooth;
- terminal Bluetooth dua arah;
- tombol mode Rover NTRIP, Rover + Logger, dan Logger RAW;
- `MODE BASE TIME 60` dengan countdown dan penyimpanan titik;
- database lokal sederhana untuk titik base;
- penggunaan ulang titik melalui command `MODE BASE latitude longitude height`;
- pilihan height MSL, ellipsoid, atau manual;
- averaging 60 detik yang hanya menerima sampel `RTK Fix`.

## Batasan penting versi MVP

1. **Belum diuji pada perangkat fisik GeoPen Hexa.** Kode dibuat dari video dan command yang diberikan.
2. Pemetaan fisik COM1/COM2 belum dibuktikan. COM1 dipakai untuk Bluetooth berdasarkan keluaran video; COM2 tetap mengikuti command base/radio dari dokumen.
3. Jenis height pada `MODE BASE` belum dipastikan untuk firmware unit. Karena itu aplikasi menyimpan MSL, geoid separation, dan ellipsoid height sekaligus dan meminta pengguna memilih.
4. Setelah `MODE BASE TIME 60`, MVP menyimpan GGA terakhir setelah 75 detik (60 detik + buffer). Ini harus diverifikasi terhadap keluaran receiver.
5. Belum ada mock location, peta, transfer file microSD, parser RTCM 1005/1006, atau ekspor CSV/KML.
6. Akun NTRIP disimpan lokal dengan SharedPreferences; untuk produksi perlu Android Keystore/encrypted storage.

## Membuka proyek

1. Install Android Studio terbaru dan Android SDK API 36.
2. Buka folder `GeoPenRTK`.
3. Tunggu Gradle Sync.
4. Hubungkan HP Android melalui USB dan aktifkan USB debugging.
5. Jalankan konfigurasi `app`.

Alternatif command line:

```bash
./gradlew assembleDebug
```

APK debug akan berada di:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Pengujian lapangan awal

1. Pair GeoPen melalui Settings Bluetooth Android (`PIN 1234` bila diminta).
2. Buka aplikasi dan izinkan **Nearby devices** serta notifikasi.
3. Pilih perangkat `EGNSS ...` pada tab Status.
4. Buka tab Mode dan kirim **Rover NTRIP**.
5. Pastikan terminal menerima `$GPGGA`.
6. Isi profil NTRIP pada tab Pengaturan.
7. Hubungkan NTRIP dan periksa byte RTCM bertambah.
8. Pastikan status bergerak `Single → Float → Fix`.
9. Lakukan uji titik yang koordinatnya sudah diketahui sebelum memakai fitur fixed base.

## Struktur kode utama

```text
bluetooth/BluetoothClassicClient.kt  Bluetooth RFCOMM/SPP
ntrip/NtripClient.kt                 NTRIP TCP + RTCM forwarding
nmea/NmeaParser.kt                   Parser NMEA
service/RtkConnectionService.kt      Foreground service koneksi
util/CommandTemplates.kt             Macro command GeoPen
ui/MainViewModel.kt                  Workflow dan averaging
ui/GeoPenApp.kt                      Antarmuka Compose
```

## Prioritas pengembangan berikutnya

1. Uji langsung dengan unit GeoPen dan simpan log.
2. Konfirmasi jenis height `MODE BASE`.
3. Parser RTCM 1005/1006 untuk membaca koordinat base secara independen.
4. Auto-reconnect Bluetooth/NTRIP dengan backoff.
5. Encrypted storage untuk password.
6. Mock location, peta, CSV/KML, dan laporan sesi.

## Build tanpa Android Studio

Proyek versi v0.2 menyertakan workflow GitHub Actions di `.github/workflows/build-apk.yml`. Panduan penggunaan dari HP tersedia di `BUILD_DARI_POCO.md`.

## Perbaikan build v0.3

Versi ini memperbaiki error Kotlin berikut pada build cloud:

```text
GeoPenApp.kt:13:43 Cannot access 'RowColumnParentData?.weight': it is internal in file
```

Penyebabnya adalah import eksplisit `androidx.compose.foundation.layout.weight`. Import tersebut dihapus; pemakaian `Modifier.weight(...)` tetap dipanggil dari scope `Row`/`Column` yang benar.
