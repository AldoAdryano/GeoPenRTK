# Cara mendapatkan APK tanpa Android Studio

## Pilihan yang disarankan: build di cloud

Laptop tidak dipakai untuk kompilasi. GitHub Actions menjalankan Gradle dan menghasilkan `app-debug.apk`.

### Yang dibutuhkan

- HP Android dan browser.
- Akun GitHub.
- Proyek ini diunggah ke sebuah repository GitHub dengan isi folder proyek berada di root repository.

### Menjalankan build

1. Buka repository di browser.
2. Buka tab **Actions**.
3. Pilih workflow **Build APK**.
4. Tekan **Run workflow** lalu **Run workflow** sekali lagi.
5. Tunggu sampai status menjadi hijau.
6. Buka hasil workflow.
7. Pada bagian **Artifacts**, unduh **GeoPenRTK-debug-apk**.
8. Ekstrak ZIP hasil artifacts, lalu instal `app-debug.apk`.

### Saat instalasi di POCO/HyperOS

- Izinkan instalasi aplikasi dari browser atau file manager yang digunakan.
- Saat aplikasi dibuka, izinkan **Nearby devices** dan **Notifications**.
- Pairing GeoPen dilakukan lebih dulu dari pengaturan Bluetooth Android.

## Alternatif: AndroidIDE di HP

Project dapat dibuka lewat AndroidIDE, tetapi instalasi awal SDK dan dependency cukup besar serta proses build lebih berat. Gunakan hanya bila build cloud tidak tersedia.

## Batas versi MVP

APK debug ini untuk pengujian lapangan, bukan untuk pengukuran resmi. Uji dulu:

- Bluetooth ke perangkat EGNSS.
- NMEA masuk stabil.
- RTCM diterima dan diteruskan.
- Status berubah SINGLE → FLOAT → FIX.
- Command base tidak mengubah tinggi secara keliru.
