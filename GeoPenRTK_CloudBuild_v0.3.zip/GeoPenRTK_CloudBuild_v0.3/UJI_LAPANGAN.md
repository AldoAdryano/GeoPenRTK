# Checklist Uji Lapangan GeoPen RTK MVP

## A. Uji Bluetooth dan COM1

- [ ] Pair perangkat EGNSS dari Settings Android.
- [ ] Hubungkan dari aplikasi.
- [ ] Kirim mode Rover NTRIP.
- [ ] Terminal menampilkan `$GPGGA` setiap 1 detik.
- [ ] Catat apakah perangkat disconnect setelah `SAVECONFIG`.
- [ ] Bila disconnect, catat waktu sampai bisa dihubungkan ulang.

## B. Uji NTRIP

- [ ] Host/port/mountpoint benar.
- [ ] GGA tersedia sebelum NTRIP dihubungkan.
- [ ] Status caster menjadi terhubung.
- [ ] Byte RTCM terus bertambah.
- [ ] Fix berubah Single → Float → Fix.
- [ ] Catat waktu mencapai Float dan Fix.
- [ ] Putuskan internet 15 detik; catat perilakunya.

## C. Uji averaging 60 detik

- [ ] Receiver RTK Fix stabil.
- [ ] Jalankan averaging.
- [ ] Pastikan sampel Float/Single dilewati.
- [ ] Ulangi tiga kali pada titik yang sama.
- [ ] Bandingkan selisih horizontal dan vertikal.

## D. Uji MODE BASE TIME 60

- [ ] Pasang base pada patok permanen dan jangan bergerak.
- [ ] Jalankan “Buat base baru”.
- [ ] Simpan seluruh terminal dari detik 0–90.
- [ ] Catat GGA sebelum dan sesudah proses.
- [ ] Matikan/nyalakan receiver dan cek apakah mode tersimpan.
- [ ] Jangan gunakan hasil untuk pekerjaan resmi sebelum dibandingkan dengan titik kontrol.

## E. Uji fixed base

Lakukan tiga percobaan pada titik fisik yang sama:

1. height MSL;
2. height ellipsoid;
3. height manual yang sudah diketahui.

Untuk setiap percobaan catat:

- command yang dikirim;
- respons receiver;
- posisi base yang diterima rover;
- elevasi rover pada titik kontrol;
- selisih horizontal dan vertikal.

Hentikan penggunaan mode yang menghasilkan bias tinggi besar.
