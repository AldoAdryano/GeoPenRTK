package com.geopen.rtk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.geopen.rtk.data.AveragingState
import com.geopen.rtk.data.BaseHeightMode
import com.geopen.rtk.data.BasePoint
import com.geopen.rtk.data.FixStatus
import com.geopen.rtk.data.GnssSnapshot
import com.geopen.rtk.data.NtripProfile
import com.geopen.rtk.data.RtkUiState
import com.geopen.rtk.util.CommandTemplates
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private enum class AppTab(val label: String) {
    DASHBOARD("Status"),
    BASE("Titik Base"),
    MODES("Mode"),
    SETTINGS("Pengaturan")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeoPenApp(vm: MainViewModel) {
    val state by vm.rtkState.collectAsStateWithLifecycle()
    val points by vm.points.collectAsStateWithLifecycle()
    val profile by vm.ntripProfile.collectAsStateWithLifecycle()
    val averaging by vm.averaging.collectAsStateWithLifecycle()
    val surveyIn by vm.surveyIn.collectAsStateWithLifecycle()
    val commandDelay by vm.commandDelay.collectAsStateWithLifecycle()

    var tab by remember { mutableStateOf(AppTab.DASHBOARD) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.error) {
        state.error?.let {
            snackbar.showSnackbar(it)
            vm.clearError()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("GeoPen RTK", fontWeight = FontWeight.Bold)
                        Text(
                            "MVP 0.3 — Unicorn/EGNSS GeoPen Hexa",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            BottomAppBar {
                AppTab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Icon(
                                imageVector = when (item) {
                                    AppTab.DASHBOARD -> Icons.Default.Home
                                    AppTab.BASE -> Icons.Default.LocationOn
                                    AppTab.MODES -> Icons.Default.Build
                                    AppTab.SETTINGS -> Icons.Default.Settings
                                },
                                contentDescription = item.label
                            )
                        },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (tab) {
                AppTab.DASHBOARD -> DashboardScreen(vm, state, averaging)
                AppTab.BASE -> BaseScreen(vm, state, points, surveyIn)
                AppTab.MODES -> ModesScreen(vm, state, commandDelay)
                AppTab.SETTINGS -> SettingsScreen(vm, profile, commandDelay)
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    vm: MainViewModel,
    state: RtkUiState,
    averaging: AveragingState
) {
    var showDevices by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var pointName by remember { mutableStateOf("Titik-${System.currentTimeMillis()}") }

    if (showDevices) {
        DeviceDialog(
            devices = vm.pairedDevices(),
            onDismiss = { showDevices = false },
            onSelect = {
                showDevices = false
                vm.connectBluetooth(it)
            }
        )
    }

    if (showSave) {
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text("Averaging RTK Fix") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pointName,
                        onValueChange = { pointName = it },
                        label = { Text("Nama titik") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Aplikasi hanya menerima sampel saat GGA menunjukkan RTK Fix (quality 4).")
                }
            },
            confirmButton = {
                Button(onClick = {
                    showSave = false
                    vm.startAveraging(pointName, 60)
                }) { Text("Mulai 60 detik") }
            },
            dismissButton = {
                TextButton(onClick = { showSave = false }) { Text("Batal") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ConnectionCard(
                title = "Bluetooth GeoPen",
                connected = state.bluetoothConnected,
                detail = if (state.bluetoothConnected) {
                    "${state.bluetoothDeviceName} • ${state.bluetoothAddress}"
                } else "Belum terhubung",
                connectLabel = if (state.bluetoothConnected) "Putuskan" else "Pilih perangkat",
                onClick = {
                    if (state.bluetoothConnected) vm.disconnectBluetooth() else showDevices = true
                }
            )
        }
        item {
            ConnectionCard(
                title = "NTRIP",
                connected = state.ntripConnected,
                detail = "${state.ntripStatus} • ${formatBytes(state.ntripBytesReceived)}",
                connectLabel = if (state.ntripConnected) "Putuskan" else "Hubungkan",
                onClick = {
                    if (state.ntripConnected) vm.disconnectNtrip() else vm.connectNtrip()
                }
            )
        }
        item { GnssStatusCard(state.gnss) }
        item {
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("Pengambilan titik", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    if (averaging.running) {
                        LinearProgressIndicator(
                            progress = {
                                averaging.secondsElapsed.toFloat() /
                                    averaging.secondsTarget.coerceAtLeast(1)
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("${averaging.secondsElapsed}/${averaging.secondsTarget} detik")
                        Text("Sampel RTK Fix: ${averaging.validFixSamples}")
                        Text(averaging.message)
                        TextButton(onClick = vm::cancelAveraging) { Text("Batalkan") }
                    } else {
                        Text(averaging.message.ifBlank {
                            "Simpan rata-rata koordinat selama 60 detik setelah RTK Fix stabil."
                        })
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { showSave = true },
                            enabled = state.gnss.fixStatus == FixStatus.RTK_FIXED
                        ) {
                            Text("Ambil titik 60 detik")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectionCard(
    title: String,
    connected: Boolean,
    detail: String,
    connectLabel: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (connected) Color(0xFFE2F5E9) else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Default.Bluetooth, contentDescription = null)
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(detail, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = onClick) { Text(connectLabel) }
        }
    }
}

@Composable
private fun GnssStatusCard(gnss: GnssSnapshot) {
    val statusColor = when (gnss.fixStatus) {
        FixStatus.RTK_FIXED -> Color(0xFF137333)
        FixStatus.RTK_FLOAT -> Color(0xFFB06000)
        FixStatus.SINGLE, FixStatus.DGPS -> Color(0xFFB3261E)
        else -> Color.DarkGray
    }
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Status GNSS", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Text(gnss.fixStatus.label, color = statusColor, fontWeight = FontWeight.Bold)
            }
            HorizontalDivider()
            ValueRow("Latitude", formatCoordinate(gnss.latitude))
            ValueRow("Longitude", formatCoordinate(gnss.longitude))
            ValueRow("Altitude MSL", gnss.altitudeMsl?.let { "%.3f m".format(Locale.US, it) } ?: "-")
            ValueRow("Geoid separation", gnss.geoidSeparation?.let { "%.3f m".format(Locale.US, it) } ?: "-")
            ValueRow("Ellipsoid height", gnss.ellipsoidHeight?.let { "%.3f m".format(Locale.US, it) } ?: "-")
            ValueRow("Satelit digunakan", gnss.satellitesUsed?.toString() ?: "-")
            ValueRow("Satelit terlihat", gnss.satellitesInView?.toString() ?: "-")
            ValueRow("HDOP / PDOP / VDOP", listOf(gnss.hdop, gnss.pdop, gnss.vdop).joinToString(" / ") { it?.let { v -> "%.2f".format(Locale.US, v) } ?: "-" })
            ValueRow("Age correction", gnss.correctionAgeSeconds?.let { "%.1f s".format(Locale.US, it) } ?: "-")
            ValueRow("Base station ID", gnss.baseStationId ?: "-")
        }
    }
}

@Composable
private fun ValueRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DeviceDialog(
    devices: List<Pair<String, String>>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Perangkat Bluetooth terpasang") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (devices.isEmpty()) {
                    Text("Tidak ada perangkat paired. Pasangkan EGNSS dari Settings Bluetooth Android terlebih dahulu.")
                }
                devices.forEach { (name, address) ->
                    TextButton(
                        onClick = { onSelect(address) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(name, fontWeight = FontWeight.Bold)
                            Text(address, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup") } }
    )
}

@Composable
private fun BaseScreen(
    vm: MainViewModel,
    state: RtkUiState,
    points: List<BasePoint>,
    surveyIn: AveragingState
) {
    var surveyName by remember { mutableStateOf("BASE-${System.currentTimeMillis()}") }
    var selectedPoint by remember { mutableStateOf<BasePoint?>(null) }

    selectedPoint?.let { point ->
        FixedBaseDialog(
            point = point,
            onDismiss = { selectedPoint = null },
            onActivate = { mode, manual ->
                vm.activateFixedBase(point, mode, manual)
                selectedPoint = null
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4D6))) {
                Column(Modifier.padding(16.dp)) {
                    Text("Base survey-in", style = MaterialTheme.typography.titleMedium)
                    Text("Menjalankan MODE BASE TIME 60 dan menyimpan GGA terakhir setelah buffer 15 detik.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = surveyName,
                        onValueChange = { surveyName = it },
                        label = { Text("Nama titik base") },
                        enabled = !surveyIn.running,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    if (surveyIn.running) {
                        LinearProgressIndicator(
                            progress = { surveyIn.secondsElapsed.toFloat() / surveyIn.secondsTarget },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(surveyIn.message)
                        TextButton(onClick = vm::cancelSurveyIn) { Text("Batalkan") }
                    } else {
                        Text(surveyIn.message)
                        Button(
                            onClick = { vm.startBaseSurveyIn(surveyName) },
                            enabled = state.bluetoothConnected
                        ) { Text("Buat base baru") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Catatan kritis: jenis height yang diterima firmware belum terverifikasi. Simpan MSL, geoid, dan ellipsoid agar tidak kehilangan data.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
        item {
            Text("Titik tersimpan (${points.size})", style = MaterialTheme.typography.titleLarge)
        }
        if (points.isEmpty()) {
            item { Text("Belum ada titik. Ambil titik dari dashboard atau jalankan base survey-in.") }
        }
        items(points, key = { it.id }) { point ->
            BasePointCard(
                point = point,
                onUse = { selectedPoint = point },
                onDelete = { vm.deletePoint(point.id) }
            )
        }
    }
}

@Composable
private fun BasePointCard(point: BasePoint, onUse: () -> Unit, onDelete: () -> Unit) {
    Card {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(point.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(DateFormat.getDateTimeInstance().format(Date(point.savedAtMillis)), style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus")
                }
            }
            Text("Lat: ${formatCoordinate(point.latitude)}")
            Text("Lon: ${formatCoordinate(point.longitude)}")
            Text("MSL: ${point.altitudeMsl?.let { "%.3f m".format(Locale.US, it) } ?: "-"}")
            Text("Ellipsoid: ${point.ellipsoidHeight?.let { "%.3f m".format(Locale.US, it) } ?: "-"}")
            Text("Fix quality: ${point.fixQuality ?: "-"} • Sat: ${point.satellitesUsed ?: "-"} • HDOP: ${point.hdop ?: "-"}")
            if (point.note.isNotBlank()) Text(point.note, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onUse, modifier = Modifier.fillMaxWidth()) {
                Text("Gunakan sebagai fixed base")
            }
        }
    }
}

@Composable
private fun FixedBaseDialog(
    point: BasePoint,
    onDismiss: () -> Unit,
    onActivate: (BaseHeightMode, Double?) -> Unit
) {
    var mode by remember { mutableStateOf(BaseHeightMode.MSL) }
    var manual by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aktifkan ${point.name}") },
        text = {
            Column {
                Text("Pilih nilai tinggi untuk command MODE BASE. Pilihan ini sengaja tidak dikunci karena firmware belum terverifikasi.")
                BaseHeightMode.entries.forEach { item ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = mode == item, onClick = { mode = item })
                        Text(item.label)
                    }
                }
                if (mode == BaseHeightMode.MANUAL) {
                    OutlinedTextField(
                        value = manual,
                        onValueChange = { manual = it },
                        label = { Text("Tinggi meter") },
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onActivate(mode, manual.toDoubleOrNull()) },
                enabled = mode != BaseHeightMode.MANUAL || manual.toDoubleOrNull() != null
            ) { Text("Kirim command") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun ModesScreen(vm: MainViewModel, state: RtkUiState, commandDelay: Long) {
    var custom by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Mode receiver", style = MaterialTheme.typography.titleLarge)
        Text("Command dikirim per baris dengan jeda $commandDelay ms.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = vm::applyRoverNtripSimple,
                enabled = state.bluetoothConnected,
                modifier = Modifier.weight(1f)
            ) { Text("Rover NTRIP") }
            Button(
                onClick = vm::applyRoverNtripLogger,
                enabled = state.bluetoothConnected,
                modifier = Modifier.weight(1f)
            ) { Text("Rover + Logger") }
        }
        OutlinedButton(
            onClick = vm::applyLoggerRaw,
            enabled = state.bluetoothConnected,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Logger RAW / Post-processing") }

        OutlinedTextField(
            value = custom,
            onValueChange = { custom = it },
            label = { Text("Command manual / multiline") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        Button(
            onClick = { vm.sendCommand(custom) },
            enabled = state.bluetoothConnected && custom.isNotBlank()
        ) { Text("Kirim command") }

        Text("Terminal", style = MaterialTheme.typography.titleMedium)
        Card(modifier = Modifier.weight(1f)) {
            SelectionContainer {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF101512))
                        .padding(8.dp)
                ) {
                    items(state.terminalLines.takeLast(150)) { line ->
                        Text(
                            line,
                            color = Color(0xFFB9F6CA),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: MainViewModel, profile: NtripProfile, commandDelay: Long) {
    var host by remember(profile) { mutableStateOf(profile.host) }
    var port by remember(profile) { mutableStateOf(profile.port.toString()) }
    var mount by remember(profile) { mutableStateOf(profile.mountPoint) }
    var user by remember(profile) { mutableStateOf(profile.username) }
    var pass by remember(profile) { mutableStateOf(profile.password) }
    var interval by remember(profile) { mutableStateOf(profile.ggaIntervalSeconds.toString()) }
    var delay by remember(commandDelay) { mutableStateOf(commandDelay.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Profil NTRIP", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(host, { host = it }, label = { Text("Host / IP") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(port, { port = it }, label = { Text("Port") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(mount, { mount = it }, label = { Text("Mountpoint") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(user, { user = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            pass,
            { pass = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(interval, { interval = it }, label = { Text("Interval kirim GGA (detik)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            vm.saveNtrip(
                NtripProfile(
                    host = host,
                    port = port.toIntOrNull() ?: 2001,
                    mountPoint = mount,
                    username = user,
                    password = pass,
                    ggaIntervalSeconds = interval.toIntOrNull() ?: 5
                )
            )
        }) { Text("Simpan NTRIP") }

        HorizontalDivider()
        Text("Command receiver", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            delay,
            { delay = it },
            label = { Text("Jeda antar-command (ms)") },
            supportingText = { Text("Disarankan 200–500 ms; jangan 0 ms sebelum diuji.") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { vm.saveCommandDelay(delay.toLongOrNull() ?: 250) }) {
            Text("Simpan jeda command")
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE8E6))) {
            Text(
                "MVP ini belum mengaktifkan mock location dan belum membuktikan pemetaan fisik COM2. Gunakan pengujian lapangan sebelum pekerjaan ukur resmi.",
                modifier = Modifier.padding(16.dp),
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

private fun formatCoordinate(value: Double?): String =
    value?.let { "%.8f".format(Locale.US, it) } ?: "-"

private fun formatBytes(value: Long): String = when {
    value >= 1_048_576 -> "%.2f MB".format(Locale.US, value / 1_048_576.0)
    value >= 1_024 -> "%.1f KB".format(Locale.US, value / 1_024.0)
    else -> "$value B"
}
