package com.geopen.rtk.util

import com.geopen.rtk.data.BaseHeightMode
import com.geopen.rtk.data.BasePoint
import java.util.Locale

object CommandTemplates {
    val roverNtripAndLogger: String = """
        unlogall com1
        config com1 115200
        config com2 115200
        CONFIG EVENT ENABLE positive 350
        unlogall com1
        unlogall com2
        mode rover
        log eventmarka onchanged
        gpgga com1 1
        GPGST com1 1
        gprmc com1 1
        GPGSA com1 1
        GPGSV com1 1
        log com2 eventalla onchanged
        obsvma com2 1
        GLOEPHEMA COM2 15
        GPSEPHEMERISA COM2 15
        GALEPHEMA COM2 15
        BDSEPHEMA COM2 15
        SAVECONFIG
    """.trimIndent()

    val roverNtripSimple: String = """
        unlogall
        config com1 115200
        config com2 115200
        CONFIG NMEA0183 V41
        unlogall
        mode rover
        CONFIG PPS disable
        gpgga com1 1
        gprmc com1 1
        SAVECONFIG
    """.trimIndent()

    val loggerRaw: String = """
        UNLOGALL
        config com1 115200
        config com2 115200
        MODE Rover
        obsvma com1 1
        gpsephemerisa com1 15
        bdsephema com1 15
        galephema com1 15
        gloephema com1 15
        CONFIG EVENT ENABLE POSITIVE 200
        log eventmarka onchanged
        SAVECONFIG
    """.trimIndent()

    val baseSurveyIn60: String = """
        unlogall com1
        unlogall com2
        config com1 115200
        config com2 115200
        mode base time 60 2.5 3.5
        RTCM1005 com2 10
        RTCM1006 com2 10
        RTCM1033 com2 10
        rtcm1074 com2 1
        rtcm1124 com2 1
        rtcm1084 com2 1
        rtcm1094 com2 1
        gpgga com1 1
        saveconfig
    """.trimIndent()

    fun fixedBase(
        point: BasePoint,
        heightMode: BaseHeightMode,
        manualHeight: Double? = null
    ): String {
        val height = when (heightMode) {
            BaseHeightMode.MSL -> point.altitudeMsl
            BaseHeightMode.ELLIPSOID -> point.ellipsoidHeight
            BaseHeightMode.MANUAL -> manualHeight
        } ?: error("Nilai tinggi untuk mode ${heightMode.label} tidak tersedia")

        val lat = String.format(Locale.US, "%.8f", point.latitude)
        val lon = String.format(Locale.US, "%.8f", point.longitude)
        val h = String.format(Locale.US, "%.3f", height)

        return """
            unlogall com1
            unlogall com2
            config com1 115200
            config com2 115200
            mode base $lat $lon $h
            RTCM1005 com2 10
            RTCM1006 com2 10
            RTCM1033 com2 10
            rtcm1074 com2 1
            rtcm1124 com2 1
            rtcm1084 com2 1
            rtcm1094 com2 1
            gpgga com1 1
            saveconfig
        """.trimIndent()
    }
}
