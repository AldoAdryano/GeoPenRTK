package com.geopen.rtk.ui

import android.app.Application
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.geopen.rtk.data.AveragingState
import com.geopen.rtk.data.BaseHeightMode
import com.geopen.rtk.data.BasePoint
import com.geopen.rtk.data.BasePointStore
import com.geopen.rtk.data.FixStatus
import com.geopen.rtk.data.NtripProfile
import com.geopen.rtk.data.PreferencesStore
import com.geopen.rtk.data.RtkRuntime
import com.geopen.rtk.service.RtkConnectionService
import com.geopen.rtk.util.CommandTemplates
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val rtkState = RtkRuntime.state

    private val pointStore = BasePointStore(application)
    private val preferences = PreferencesStore(application)

    private val _points = MutableStateFlow(pointStore.load())
    val points: StateFlow<List<BasePoint>> = _points.asStateFlow()

    private val _ntripProfile = MutableStateFlow(preferences.loadNtrip())
    val ntripProfile: StateFlow<NtripProfile> = _ntripProfile.asStateFlow()

    private val _commandDelay = MutableStateFlow(preferences.commandDelayMillis())
    val commandDelay: StateFlow<Long> = _commandDelay.asStateFlow()

    private val _averaging = MutableStateFlow(AveragingState())
    val averaging: StateFlow<AveragingState> = _averaging.asStateFlow()

    private val _surveyIn = MutableStateFlow(AveragingState(secondsTarget = 75))
    val surveyIn: StateFlow<AveragingState> = _surveyIn.asStateFlow()

    private var averagingJob: Job? = null
    private var surveyJob: Job? = null

    @Suppress("MissingPermission")
    fun pairedDevices(): List<Pair<String, String>> {
        val manager = getApplication<Application>()
            .getSystemService(BluetoothManager::class.java)
        return runCatching {
            manager.adapter?.bondedDevices
                ?.map { (it.name ?: "Tanpa nama") to it.address }
                ?.sortedBy { it.first }
                .orEmpty()
        }.getOrDefault(emptyList())
    }

    fun connectBluetooth(address: String) {
        sendServiceIntent(RtkConnectionService.ACTION_CONNECT_BT) {
            putExtra(RtkConnectionService.EXTRA_ADDRESS, address)
        }
    }

    fun disconnectBluetooth() =
        sendServiceIntent(RtkConnectionService.ACTION_DISCONNECT_BT)

    fun connectNtrip() =
        sendServiceIntent(RtkConnectionService.ACTION_CONNECT_NTRIP)

    fun disconnectNtrip() =
        sendServiceIntent(RtkConnectionService.ACTION_DISCONNECT_NTRIP)

    fun sendCommand(command: String) {
        sendServiceIntent(RtkConnectionService.ACTION_SEND_COMMAND) {
            putExtra(RtkConnectionService.EXTRA_COMMAND, command)
            putExtra(RtkConnectionService.EXTRA_DELAY, _commandDelay.value)
        }
    }

    fun applyRoverNtripSimple() = sendCommand(CommandTemplates.roverNtripSimple)
    fun applyRoverNtripLogger() = sendCommand(CommandTemplates.roverNtripAndLogger)
    fun applyLoggerRaw() = sendCommand(CommandTemplates.loggerRaw)

    fun saveNtrip(profile: NtripProfile) {
        val clean = profile.copy(
            host = profile.host.trim(),
            mountPoint = profile.mountPoint.trim().trimStart('/'),
            port = profile.port.coerceIn(1, 65535),
            ggaIntervalSeconds = profile.ggaIntervalSeconds.coerceIn(1, 60)
        )
        preferences.saveNtrip(clean)
        _ntripProfile.value = clean
    }

    fun saveCommandDelay(value: Long) {
        val clean = value.coerceIn(50, 2_000)
        preferences.saveCommandDelayMillis(clean)
        _commandDelay.value = clean
    }

    fun saveCurrentPoint(name: String, note: String = ""): Result<BasePoint> {
        val gnss = rtkState.value.gnss
        val lat = gnss.latitude ?: return Result.failure(IllegalStateException("Latitude belum tersedia"))
        val lon = gnss.longitude ?: return Result.failure(IllegalStateException("Longitude belum tersedia"))
        val point = BasePoint(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Titik-${System.currentTimeMillis()}" },
            latitude = lat,
            longitude = lon,
            altitudeMsl = gnss.altitudeMsl,
            geoidSeparation = gnss.geoidSeparation,
            ellipsoidHeight = gnss.ellipsoidHeight,
            savedAtMillis = System.currentTimeMillis(),
            fixQuality = gnss.fixQuality,
            satellitesUsed = gnss.satellitesUsed,
            hdop = gnss.hdop,
            note = note
        )
        pointStore.save(point)
        _points.value = pointStore.load()
        return Result.success(point)
    }

    fun deletePoint(id: String) {
        pointStore.delete(id)
        _points.value = pointStore.load()
    }

    fun activateFixedBase(
        point: BasePoint,
        mode: BaseHeightMode,
        manualHeight: Double?
    ): Result<Unit> = runCatching {
        val command = CommandTemplates.fixedBase(point, mode, manualHeight)
        sendCommand(command)
    }

    fun startAveraging(name: String, seconds: Int = 60) {
        averagingJob?.cancel()
        averagingJob = viewModelScope.launch {
            val latitudes = mutableListOf<Double>()
            val longitudes = mutableListOf<Double>()
            val altitudes = mutableListOf<Double>()
            val geoids = mutableListOf<Double>()

            _averaging.value = AveragingState(
                running = true,
                secondsTarget = seconds,
                message = "Menunggu sampel RTK Fix"
            )

            repeat(seconds) { index ->
                val gnss = rtkState.value.gnss
                if (gnss.fixStatus == FixStatus.RTK_FIXED &&
                    gnss.latitude != null && gnss.longitude != null
                ) {
                    latitudes += gnss.latitude
                    longitudes += gnss.longitude
                    gnss.altitudeMsl?.let(altitudes::add)
                    gnss.geoidSeparation?.let(geoids::add)
                }
                _averaging.update {
                    it.copy(
                        secondsElapsed = index + 1,
                        validFixSamples = latitudes.size,
                        message = if (gnss.fixStatus == FixStatus.RTK_FIXED) {
                            "RTK Fix — sampel diterima"
                        } else {
                            "Sampel dilewati: ${gnss.fixStatus.label}"
                        }
                    )
                }
                delay(1_000)
            }

            val minimum = (seconds * 0.8).toInt()
            if (latitudes.size < minimum) {
                _averaging.update {
                    it.copy(
                        running = false,
                        message = "Gagal: hanya ${latitudes.size}/$seconds sampel RTK Fix"
                    )
                }
                return@launch
            }

            val msl = altitudes.takeIf { it.isNotEmpty() }?.average()
            val geoid = geoids.takeIf { it.isNotEmpty() }?.average()
            val point = BasePoint(
                id = UUID.randomUUID().toString(),
                name = name.trim().ifBlank { "Average-${System.currentTimeMillis()}" },
                latitude = latitudes.average(),
                longitude = longitudes.average(),
                altitudeMsl = msl,
                geoidSeparation = geoid,
                ellipsoidHeight = if (msl != null && geoid != null) msl + geoid else null,
                savedAtMillis = System.currentTimeMillis(),
                fixQuality = 4,
                satellitesUsed = rtkState.value.gnss.satellitesUsed,
                hdop = rtkState.value.gnss.hdop,
                note = "Averaging $seconds detik; ${latitudes.size} sampel RTK Fix"
            )
            pointStore.save(point)
            _points.value = pointStore.load()
            _averaging.update {
                it.copy(running = false, message = "Berhasil menyimpan ${point.name}")
            }
        }
    }

    fun cancelAveraging() {
        averagingJob?.cancel()
        _averaging.value = AveragingState(message = "Dibatalkan")
    }

    fun startBaseSurveyIn(name: String) {
        surveyJob?.cancel()
        sendCommand(CommandTemplates.baseSurveyIn60)
        surveyJob = viewModelScope.launch {
            val target = 75 // 60 detik survey-in + buffer penerimaan command/posisi.
            _surveyIn.value = AveragingState(
                running = true,
                secondsTarget = target,
                message = "Base survey-in berjalan. Jangan pindahkan antena."
            )
            repeat(target) { index ->
                _surveyIn.update {
                    it.copy(
                        secondsElapsed = index + 1,
                        validFixSamples = 0,
                        message = "Survey-in ${index + 1}/$target detik"
                    )
                }
                delay(1_000)
            }
            val result = saveCurrentPoint(
                name = name.ifBlank { "BASE-${System.currentTimeMillis()}" },
                note = "Disimpan setelah MODE BASE TIME 60; perlu validasi jenis height pada unit"
            )
            _surveyIn.update {
                it.copy(
                    running = false,
                    message = result.fold(
                        onSuccess = { point -> "Survey-in selesai; ${point.name} tersimpan" },
                        onFailure = { error -> "Survey-in selesai, tetapi koordinat gagal disimpan: ${error.message}" }
                    )
                )
            }
        }
    }

    fun cancelSurveyIn() {
        surveyJob?.cancel()
        _surveyIn.value = AveragingState(secondsTarget = 75, message = "Dibatalkan")
    }

    fun clearError() = RtkRuntime.clearError()

    private fun sendServiceIntent(action: String, extras: Intent.() -> Unit = {}) {
        val context = getApplication<Application>()
        val intent = Intent(context, RtkConnectionService::class.java).apply {
            this.action = action
            extras()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(context, intent)
        } else {
            context.startService(intent)
        }
    }
}
