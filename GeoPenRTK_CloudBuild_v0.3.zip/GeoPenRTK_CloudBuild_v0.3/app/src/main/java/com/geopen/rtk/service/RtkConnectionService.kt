package com.geopen.rtk.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.geopen.rtk.MainActivity
import com.geopen.rtk.bluetooth.BluetoothClassicClient
import com.geopen.rtk.data.NtripProfile
import com.geopen.rtk.data.PreferencesStore
import com.geopen.rtk.data.RtkRuntime
import com.geopen.rtk.nmea.NmeaParser
import com.geopen.rtk.ntrip.NtripClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class RtkConnectionService : Service() {
    companion object {
        const val ACTION_CONNECT_BT = "com.geopen.rtk.CONNECT_BT"
        const val ACTION_DISCONNECT_BT = "com.geopen.rtk.DISCONNECT_BT"
        const val ACTION_CONNECT_NTRIP = "com.geopen.rtk.CONNECT_NTRIP"
        const val ACTION_DISCONNECT_NTRIP = "com.geopen.rtk.DISCONNECT_NTRIP"
        const val ACTION_SEND_COMMAND = "com.geopen.rtk.SEND_COMMAND"
        const val ACTION_STOP_ALL = "com.geopen.rtk.STOP_ALL"

        const val EXTRA_ADDRESS = "address"
        const val EXTRA_COMMAND = "command"
        const val EXTRA_DELAY = "delay"

        private const val CHANNEL_ID = "rtk_connection"
        private const val NOTIFICATION_ID = 741
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var bluetooth: BluetoothClassicClient
    private lateinit var ntrip: NtripClient
    private lateinit var preferences: PreferencesStore

    override fun onCreate() {
        super.onCreate()
        preferences = PreferencesStore(this)
        createNotificationChannel()
        startAsForeground("Siap menghubungkan GeoPen")

        bluetooth = BluetoothClassicClient(
            context = this,
            scope = scope,
            onLine = ::handleBluetoothLine,
            onConnected = { name, address ->
                RtkRuntime.update {
                    it.copy(
                        bluetoothConnected = true,
                        bluetoothDeviceName = name,
                        bluetoothAddress = address,
                        error = null
                    )
                }
                updateNotification("Bluetooth terhubung: $name")
                RtkRuntime.appendTerminal("BT CONNECTED: $name ($address)")
            },
            onDisconnected = { reason ->
                ntrip.disconnect()
                RtkRuntime.update {
                    it.copy(
                        bluetoothConnected = false,
                        ntripConnected = false,
                        ntripStatus = "Terputus",
                        error = reason?.takeIf { message -> message.isNotBlank() }
                    )
                }
                updateNotification("GeoPen terputus")
                if (!reason.isNullOrBlank()) RtkRuntime.appendTerminal("BT DISCONNECTED: $reason")
            }
        )

        ntrip = NtripClient(
            scope = scope,
            latestGga = { RtkRuntime.state.value.latestGga },
            onRtcmBytes = { bytes -> bluetooth.write(bytes) },
            onStatus = { connected, message ->
                RtkRuntime.update { it.copy(ntripConnected = connected, ntripStatus = message) }
                updateNotification(message)
                RtkRuntime.appendTerminal("NTRIP: $message")
            },
            onBytesReceived = { total ->
                RtkRuntime.update { it.copy(ntripBytesReceived = total) }
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT_BT -> connectBluetooth(intent.getStringExtra(EXTRA_ADDRESS))
            ACTION_DISCONNECT_BT -> bluetooth.disconnect("Diputuskan pengguna")
            ACTION_CONNECT_NTRIP -> connectNtrip()
            ACTION_DISCONNECT_NTRIP -> {
                ntrip.disconnect()
                RtkRuntime.update { it.copy(ntripConnected = false, ntripStatus = "Terputus") }
            }
            ACTION_SEND_COMMAND -> sendCommand(
                intent.getStringExtra(EXTRA_COMMAND).orEmpty(),
                intent.getLongExtra(EXTRA_DELAY, preferences.commandDelayMillis())
            )
            ACTION_STOP_ALL -> {
                ntrip.disconnect()
                bluetooth.disconnect("Layanan dihentikan")
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun connectBluetooth(address: String?) {
        if (address.isNullOrBlank()) {
            setError("Alamat Bluetooth tidak valid")
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            setError("Izin Nearby devices belum diberikan")
            return
        }

        scope.launch {
            runCatching { bluetooth.connect(address) }
                .onFailure { setError("Bluetooth gagal: ${it.message}") }
        }
    }

    private fun connectNtrip() {
        if (!bluetooth.isConnected()) {
            setError("Hubungkan GeoPen terlebih dahulu")
            return
        }
        val profile = preferences.loadNtrip()
        if (profile.host.isBlank() || profile.mountPoint.isBlank()) {
            setError("Profil NTRIP belum lengkap")
            return
        }
        scope.launch {
            runCatching { ntrip.connect(profile) }
                .onFailure {
                    RtkRuntime.update { state ->
                        state.copy(
                            ntripConnected = false,
                            ntripStatus = "Gagal: ${it.message}",
                            error = "NTRIP gagal: ${it.message}"
                        )
                    }
                }
        }
    }

    private fun sendCommand(command: String, delay: Long) {
        if (command.isBlank()) return
        if (!bluetooth.isConnected()) {
            setError("Bluetooth belum terhubung")
            return
        }
        scope.launch {
            runCatching { bluetooth.sendMultiline(command, delay.coerceIn(50L, 2_000L)) }
                .onFailure { setError("Command gagal: ${it.message}") }
        }
    }

    private fun handleBluetoothLine(line: String) {
        RtkRuntime.appendTerminal("RX: $line")
        if (line.startsWith("\$")) {
            val current = RtkRuntime.state.value
            val parsed = NmeaParser.parse(line, current.gnss)
            RtkRuntime.update {
                it.copy(
                    gnss = parsed,
                    latestGga = if (line.contains("GGA,")) line else it.latestGga,
                    error = null
                )
            }
        }
    }

    private fun setError(message: String) {
        RtkRuntime.update { it.copy(error = message) }
        RtkRuntime.appendTerminal("ERROR: $message")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Koneksi RTK",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menjaga koneksi Bluetooth GeoPen dan NTRIP tetap aktif"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startAsForeground(text: String) {
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(text),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            } else 0
        )
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(com.geopen.rtk.R.drawable.ic_launcher_foreground)
        .setContentTitle("GeoPen RTK")
        .setContentText(text)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .build()

    override fun onDestroy() {
        ntrip.disconnect()
        bluetooth.disconnect(null)
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
