package com.geopen.rtk.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class BasePointStore(context: Context) {
    private val file = File(context.filesDir, "base_points.json")

    @Synchronized
    fun load(): List<BasePoint> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val array = JSONArray(file.readText())
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(item.toBasePoint())
                }
            }.sortedByDescending { it.savedAtMillis }
        }.getOrElse { emptyList() }
    }

    @Synchronized
    fun save(point: BasePoint) {
        val updated = load().filterNot { it.id == point.id } + point
        write(updated)
    }

    @Synchronized
    fun delete(id: String) {
        write(load().filterNot { it.id == id })
    }

    private fun write(points: List<BasePoint>) {
        val array = JSONArray()
        points.forEach { array.put(it.toJson()) }
        file.writeText(array.toString(2))
    }

    private fun BasePoint.toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("latitude", latitude)
        put("longitude", longitude)
        putNullable("altitudeMsl", altitudeMsl)
        putNullable("geoidSeparation", geoidSeparation)
        putNullable("ellipsoidHeight", ellipsoidHeight)
        put("savedAtMillis", savedAtMillis)
        putNullable("fixQuality", fixQuality)
        putNullable("satellitesUsed", satellitesUsed)
        putNullable("hdop", hdop)
        put("note", note)
    }

    private fun JSONObject.toBasePoint(): BasePoint = BasePoint(
        id = getString("id"),
        name = getString("name"),
        latitude = getDouble("latitude"),
        longitude = getDouble("longitude"),
        altitudeMsl = optNullableDouble("altitudeMsl"),
        geoidSeparation = optNullableDouble("geoidSeparation"),
        ellipsoidHeight = optNullableDouble("ellipsoidHeight"),
        savedAtMillis = getLong("savedAtMillis"),
        fixQuality = optNullableInt("fixQuality"),
        satellitesUsed = optNullableInt("satellitesUsed"),
        hdop = optNullableDouble("hdop"),
        note = optString("note", "")
    )

    private fun JSONObject.putNullable(key: String, value: Any?) {
        if (value == null) put(key, JSONObject.NULL) else put(key, value)
    }

    private fun JSONObject.optNullableDouble(key: String): Double? =
        if (!has(key) || isNull(key)) null else optDouble(key)

    private fun JSONObject.optNullableInt(key: String): Int? =
        if (!has(key) || isNull(key)) null else optInt(key)
}
