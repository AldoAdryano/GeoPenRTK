package com.geopen.rtk.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import com.geopen.rtk.data.RtkRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

class BluetoothClassicClient(
    context: Context,
    private val scope: CoroutineScope,
    private val onLine: (String) -> Unit,
    private val onConnected: (String, String) -> Unit,
    private val onDisconnected: (String?) -> Unit
) {
    companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var readJob: Job? = null
    private val closing = AtomicBoolean(false)

    @SuppressLint("MissingPermission")
    suspend fun connect(address: String) = withContext(Dispatchers.IO) {
        disconnect(null)
        val bluetoothAdapter = adapter ?: throw IOException("Bluetooth tidak tersedia")
        val device = bluetoothAdapter.getRemoteDevice(address)
        bluetoothAdapter.cancelDiscovery()
        closing.set(false)

        val newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
        newSocket.connect()
        socket = newSocket
        input = newSocket.inputStream
        output = newSocket.outputStream
        onConnected(device.name ?: "GeoPen", device.address)
        startReader()
    }

    private fun startReader() {
        readJob?.cancel()
        readJob = scope.launch(Dispatchers.IO) {
            val stream = input ?: return@launch
            val buffer = ByteArray(2048)
            val lineBuffer = StringBuilder()

            try {
                while (isActive && !closing.get()) {
                    val count = stream.read(buffer)
                    if (count < 0) break
                    for (i in 0 until count) {
                        val byte = buffer[i].toInt() and 0xFF
                        when (byte) {
                            10 -> {
                                val line = lineBuffer.toString().trimEnd('\r')
                                lineBuffer.clear()
                                if (line.isNotBlank()) onLine(line)
                            }
                            13 -> Unit
                            in 32..126 -> lineBuffer.append(byte.toChar())
                            else -> {
                                // Data non-ASCII dari receiver tidak dibuang diam-diam.
                                // Untuk MVP, tampilkan sebagai token hex agar terminal tetap diagnostik.
                                if (lineBuffer.length < 1024) {
                                    lineBuffer.append("<%02X>".format(byte))
                                }
                            }
                        }

                        if (lineBuffer.length > 4096) {
                            onLine(lineBuffer.toString())
                            lineBuffer.clear()
                        }
                    }
                }
                if (lineBuffer.isNotBlank()) onLine(lineBuffer.toString())
            } catch (e: Exception) {
                if (!closing.get()) onDisconnected(e.message)
            } finally {
                if (!closing.get()) closeResources()
            }
        }
    }

    suspend fun write(bytes: ByteArray) = withContext(Dispatchers.IO) {
        val stream = output ?: throw IOException("Bluetooth belum terhubung")
        synchronized(this@BluetoothClassicClient) {
            stream.write(bytes)
            stream.flush()
        }
    }

    suspend fun writeText(text: String) {
        val normalized = if (text.endsWith("\r\n")) text else "$text\r\n"
        write(normalized.toByteArray(Charsets.US_ASCII))
        RtkRuntime.appendTerminal("TX: ${text.trim()}")
    }

    suspend fun sendMultiline(command: String, delayMillis: Long = 250L) {
        command.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .forEach { line ->
                writeText(line)
                kotlinx.coroutines.delay(delayMillis)
            }
    }

    fun isConnected(): Boolean = socket?.isConnected == true

    fun disconnect(reason: String? = null) {
        closing.set(true)
        readJob?.cancel()
        closeResources()
        onDisconnected(reason)
    }

    private fun closeResources() {
        runCatching { input?.close() }
        runCatching { output?.close() }
        runCatching { socket?.close() }
        input = null
        output = null
        socket = null
    }
}
