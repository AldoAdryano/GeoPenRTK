package com.geopen.rtk.nmea

import com.geopen.rtk.data.FixStatus
import com.geopen.rtk.data.GnssSnapshot
import kotlin.math.abs

object NmeaParser {
    fun parse(line: String, previous: GnssSnapshot): GnssSnapshot {
        if (!line.startsWith("\$")) return previous
        if (!isChecksumValid(line)) return previous.copy(lastSentence = line)

        val body = line.substringBefore('*')
        val fields = body.split(',')
        val type = fields.firstOrNull()?.takeLast(3) ?: return previous
        val now = System.currentTimeMillis()

        return when (type) {
            "GGA" -> parseGga(fields, previous, line, now)
            "RMC" -> parseRmc(fields, previous, line, now)
            "GSA" -> parseGsa(fields, previous, line, now)
            "GSV" -> parseGsv(fields, previous, line, now)
            "GST" -> parseGst(fields, previous, line, now)
            else -> previous.copy(lastSentence = line, updatedAtMillis = now)
        }
    }

    private fun parseGga(
        f: List<String>,
        p: GnssSnapshot,
        line: String,
        now: Long
    ): GnssSnapshot {
        val lat = coordinateToDecimal(f.getOrNull(2), f.getOrNull(3), true)
        val lon = coordinateToDecimal(f.getOrNull(4), f.getOrNull(5), false)
        val quality = f.getOrNull(6)?.toIntOrNull()
        val altitude = f.getOrNull(9)?.toDoubleOrNull()
        val geoid = f.getOrNull(11)?.toDoubleOrNull()
        val ellipsoid = if (altitude != null && geoid != null) altitude + geoid else null

        return p.copy(
            utc = f.getOrNull(1).orEmpty().ifBlank { p.utc },
            latitude = lat ?: p.latitude,
            longitude = lon ?: p.longitude,
            altitudeMsl = altitude ?: p.altitudeMsl,
            geoidSeparation = geoid ?: p.geoidSeparation,
            ellipsoidHeight = ellipsoid ?: p.ellipsoidHeight,
            fixQuality = quality,
            fixStatus = FixStatus.fromGgaQuality(quality),
            satellitesUsed = f.getOrNull(7)?.toIntOrNull() ?: p.satellitesUsed,
            hdop = f.getOrNull(8)?.toDoubleOrNull() ?: p.hdop,
            correctionAgeSeconds = f.getOrNull(13)?.toDoubleOrNull(),
            baseStationId = f.getOrNull(14)?.ifBlank { null },
            lastSentence = line,
            updatedAtMillis = now
        )
    }

    private fun parseRmc(
        f: List<String>,
        p: GnssSnapshot,
        line: String,
        now: Long
    ): GnssSnapshot {
        val valid = f.getOrNull(2) == "A"
        val lat = if (valid) coordinateToDecimal(f.getOrNull(3), f.getOrNull(4), true) else null
        val lon = if (valid) coordinateToDecimal(f.getOrNull(5), f.getOrNull(6), false) else null
        return p.copy(
            utc = f.getOrNull(1).orEmpty().ifBlank { p.utc },
            latitude = lat ?: p.latitude,
            longitude = lon ?: p.longitude,
            speedKnots = f.getOrNull(7)?.toDoubleOrNull(),
            trackDegrees = f.getOrNull(8)?.toDoubleOrNull(),
            lastSentence = line,
            updatedAtMillis = now
        )
    }

    private fun parseGsa(
        f: List<String>,
        p: GnssSnapshot,
        line: String,
        now: Long
    ): GnssSnapshot {
        val size = f.size
        return p.copy(
            pdop = f.getOrNull(size - 3)?.toDoubleOrNull() ?: p.pdop,
            hdop = f.getOrNull(size - 2)?.toDoubleOrNull() ?: p.hdop,
            vdop = f.getOrNull(size - 1)?.substringBefore('*')?.toDoubleOrNull() ?: p.vdop,
            lastSentence = line,
            updatedAtMillis = now
        )
    }

    private fun parseGsv(
        f: List<String>,
        p: GnssSnapshot,
        line: String,
        now: Long
    ): GnssSnapshot = p.copy(
        satellitesInView = f.getOrNull(3)?.toIntOrNull() ?: p.satellitesInView,
        lastSentence = line,
        updatedAtMillis = now
    )

    private fun parseGst(
        f: List<String>,
        p: GnssSnapshot,
        line: String,
        now: Long
    ): GnssSnapshot = p.copy(
        sigmaLatitudeMeters = f.getOrNull(6)?.toDoubleOrNull() ?: p.sigmaLatitudeMeters,
        sigmaLongitudeMeters = f.getOrNull(7)?.toDoubleOrNull() ?: p.sigmaLongitudeMeters,
        sigmaAltitudeMeters = f.getOrNull(8)?.substringBefore('*')?.toDoubleOrNull() ?: p.sigmaAltitudeMeters,
        lastSentence = line,
        updatedAtMillis = now
    )

    fun isChecksumValid(line: String): Boolean {
        val star = line.indexOf('*')
        if (star < 0 || star + 2 >= line.length) return true
        val expected = line.substring(star + 1).take(2).toIntOrNull(16) ?: return false
        var actual = 0
        for (i in 1 until star) actual = actual xor line[i].code
        return actual == expected
    }

    private fun coordinateToDecimal(
        value: String?,
        hemisphere: String?,
        latitude: Boolean
    ): Double? {
        val raw = value?.toDoubleOrNull() ?: return null
        val degrees = if (latitude) (raw / 100).toInt() else (raw / 100).toInt()
        val minutes = raw - degrees * 100
        var result = degrees + minutes / 60.0
        if (hemisphere == "S" || hemisphere == "W") result *= -1
        if (latitude && abs(result) > 90) return null
        if (!latitude && abs(result) > 180) return null
        return result
    }
}
