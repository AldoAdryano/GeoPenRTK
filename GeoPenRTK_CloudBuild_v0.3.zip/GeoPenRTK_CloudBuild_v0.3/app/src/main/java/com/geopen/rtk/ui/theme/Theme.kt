package com.geopen.rtk.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0E5D45),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC2F1DA),
    secondary = Color(0xFF4E6358),
    tertiary = Color(0xFF3D6374),
    error = Color(0xFFBA1A1A),
    background = Color(0xFFF7FAF7),
    surface = Color(0xFFF7FAF7)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA6D5BF),
    primaryContainer = Color(0xFF004D36),
    secondary = Color(0xFFB6CCBF),
    tertiary = Color(0xFFA5CDDF)
)

@Composable
fun GeoPenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
