package com.geopen.rtk.ntrip

import android.util.Base64
import com.geopen.rtk.data.NtripProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

class NtripClient(
    private val scope: CoroutineScope,
    private val latestGga: () -> String?,
    private val onRtcmBytes: suspend (ByteArray) -> Unit,
    private val onStatus: (connected: Boolean, message: String) -> Unit,
    private val onBytesReceived: (Long) -> Unit
) {
    private var socket: Socket? = null
    private var input: BufferedInputStream? = null
    private var output: BufferedOutputStream? = null
    private var readJob: Job? = null
    private var ggaJob: Job? = null
    private var totalBytes: Long = 0

    suspend fun connect(profile: NtripProfile) = withContext(Dispatchers.IO) {
        disconnect()
        onStatus(false, "Menghubungkan ke caster...")

        val newSocket = Socket()
        newSocket.connect(InetSocketAddress(profile.host, profile.port), 12_000)
        newSocket.soTimeout = 20_000
        socket = newSocket
        input = BufferedInputStream(newSocket.getInputStream(), 16 * 1024)
        output = BufferedOutputStream(newSocket.getOutputStream(), 8 * 1024)

        sendRequest(profile)
        val header = readHeader(input ?: throw IOException("Input NTRIP tidak tersedia"))
        val accepted = header.contains("ICY 200", ignoreCase = true) ||
            header.contains("HTTP/1.0 200", ignoreCase = true) ||
            header.contains("HTTP/1.1 200", ignoreCase = true)

        if (!accepted) {
            disconnect()
            throw IOException("Caster menolak koneksi: ${header.lineSequence().firstOrNull()}")
        }

        totalBytes = 0
        onStatus(true, "Terhubung: ${profile.mountPoint}")
        sendGgaNow()
        startReader()
        startGgaSender(profile.ggaIntervalSeconds.coerceIn(1, 60))
    }

    private fun sendRequest(profile: NtripProfile) {
        val credentials = "${profile.username}:${profile.password}"
        val auth = Base64.encodeToString(credentials.toByteArray(), Base64.NO_WRAP)
        val mount = profile.mountPoint.trim().trimStart('/')
        val request = buildString {
            append("GET /$mount HTTP/1.0\r\n")
            append("User-Agent: NTRIP GeoPenRTK/0.1\r\n")
            append("Ntrip-Version: Ntrip/2.0\r\n")
            append("Authorization: Basic $auth\r\n")
            append("Accept: */*\r\n")
            append("Connection: close\r\n")
            append("\r\n")
        }
        output?.apply {
            write(request.toByteArray(Charsets.US_ASCII))
            flush()
        }
    }

    private fun readHeader(stream: BufferedInputStream): String {
        val output = ByteArrayOutputStream()
        var matched = 0
        val ending = byteArrayOf(13, 10, 13, 10)
        while (output.size() < 16_384) {
            val value = stream.read()
            if (value < 0) break
            output.write(value)
            if (value.toByte() == ending[matched]) {
                matched++
                if (matched == ending.size) break
            } else {
                matched = if (value.toByte() == ending[0]) 1 else 0
            }
        }
        return output.toString(Charsets.US_ASCII.name())
    }

    private fun startReader() {
        readJob = scope.launch(Dispatchers.IO) {
            val stream = input ?: return@launch
            val buffer = ByteArray(4096)
            try {
                while (isActive) {
                    val count = stream.read(buffer)
                    if (count < 0) throw IOException("Stream caster ditutup")
                    if (count == 0) continue
                    val bytes = buffer.copyOf(count)
                    onRtcmBytes(bytes)
                    totalBytes += count
                    onBytesReceived(totalBytes)
                }
            } catch (e: Exception) {
                if (isActive) onStatus(false, "NTRIP terputus: ${e.message}")
            } finally {
                disconnect()
            }
        }
    }

    private fun startGgaSender(intervalSeconds: Int) {
        ggaJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(intervalSeconds * 1_000L)
                runCatching { sendGgaNow() }
            }
        }
    }

    private fun sendGgaNow() {
        val gga = latestGga()?.trim()?.takeIf { it.startsWith("\$") } ?: return
        output?.apply {
            write("$gga\r\n".toByteArray(Charsets.US_ASCII))
            flush()
        }
    }

    fun disconnect() {
        readJob?.cancel()
        ggaJob?.cancel()
        readJob = null
        ggaJob = null
        runCatching { input?.close() }
        runCatching { output?.close() }
        runCatching { socket?.close() }
        input = null
        output = null
        socket = null
    }
}
