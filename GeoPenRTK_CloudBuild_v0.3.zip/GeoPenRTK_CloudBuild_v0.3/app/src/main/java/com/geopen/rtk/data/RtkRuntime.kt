package com.geopen.rtk.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

object RtkRuntime {
    private val _state = MutableStateFlow(RtkUiState())
    val state: StateFlow<RtkUiState> = _state

    fun update(block: (RtkUiState) -> RtkUiState) {
        _state.update(block)
    }

    fun appendTerminal(line: String) {
        val timestamped = "${System.currentTimeMillis()} | $line"
        _state.update { current ->
            current.copy(terminalLines = (current.terminalLines + timestamped).takeLast(250))
        }
    }

    fun clearError() = _state.update { it.copy(error = null) }
}
