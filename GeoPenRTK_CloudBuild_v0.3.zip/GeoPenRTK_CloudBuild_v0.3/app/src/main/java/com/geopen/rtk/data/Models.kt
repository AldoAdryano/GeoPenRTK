package com.geopen.rtk.data

enum class FixStatus(val label: String) {
    NO_FIX("Tidak ada posisi"),
    SINGLE("Single"),
    DGPS("DGPS"),
    RTK_FIXED("RTK Fix"),
    RTK_FLOAT("RTK Float"),
    ESTIMATED("Estimated"),
    UNKNOWN("Unknown");

    companion object {
        fun fromGgaQuality(value: Int?): FixStatus = when (value) {
            0, null -> NO_FIX
            1 -> SINGLE
            2 -> DGPS
            4 -> RTK_FIXED
            5 -> RTK_FLOAT
            6 -> ESTIMATED
            else -> UNKNOWN
        }
    }
}

data class GnssSnapshot(
    val utc: String = "-",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val altitudeMsl: Double? = null,
    val geoidSeparation: Double? = null,
    val ellipsoidHeight: Double? = null,
    val fixQuality: Int? = null,
    val fixStatus: FixStatus = FixStatus.NO_FIX,
    val satellitesUsed: Int? = null,
    val satellitesInView: Int? = null,
    val hdop: Double? = null,
    val pdop: Double? = null,
    val vdop: Double? = null,
    val correctionAgeSeconds: Double? = null,
    val baseStationId: String? = null,
    val speedKnots: Double? = null,
    val trackDegrees: Double? = null,
    val sigmaLatitudeMeters: Double? = null,
    val sigmaLongitudeMeters: Double? = null,
    val sigmaAltitudeMeters: Double? = null,
    val lastSentence: String? = null,
    val updatedAtMillis: Long = 0L
)

data class RtkUiState(
    val bluetoothConnected: Boolean = false,
    val bluetoothDeviceName: String? = null,
    val bluetoothAddress: String? = null,
    val ntripConnected: Boolean = false,
    val ntripStatus: String = "Terputus",
    val ntripBytesReceived: Long = 0,
    val gnss: GnssSnapshot = GnssSnapshot(),
    val latestGga: String? = null,
    val terminalLines: List<String> = emptyList(),
    val error: String? = null
)

data class NtripProfile(
    val host: String = "103.22.171.6",
    val port: Int = 2001,
    val mountPoint: String = "Nearest-rtcm3",
    val username: String = "",
    val password: String = "",
    val ggaIntervalSeconds: Int = 5
)

enum class BaseHeightMode(val label: String) {
    MSL("Altitude MSL dari GGA"),
    ELLIPSOID("Ellipsoid height = MSL + geoid"),
    MANUAL("Tinggi manual")
}

data class BasePoint(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val altitudeMsl: Double?,
    val geoidSeparation: Double?,
    val ellipsoidHeight: Double?,
    val savedAtMillis: Long,
    val fixQuality: Int?,
    val satellitesUsed: Int?,
    val hdop: Double?,
    val note: String = ""
)

data class AveragingState(
    val running: Boolean = false,
    val secondsTarget: Int = 60,
    val secondsElapsed: Int = 0,
    val validFixSamples: Int = 0,
    val message: String = ""
)
