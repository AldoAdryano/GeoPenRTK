package com.geopen.rtk.data

import android.content.Context

class PreferencesStore(context: Context) {
    private val prefs = context.getSharedPreferences("geopen_rtk", Context.MODE_PRIVATE)

    fun loadNtrip(): NtripProfile = NtripProfile(
        host = prefs.getString("ntrip_host", "103.22.171.6").orEmpty(),
        port = prefs.getInt("ntrip_port", 2001),
        mountPoint = prefs.getString("ntrip_mount", "Nearest-rtcm3").orEmpty(),
        username = prefs.getString("ntrip_user", "").orEmpty(),
        password = prefs.getString("ntrip_pass", "").orEmpty(),
        ggaIntervalSeconds = prefs.getInt("ntrip_gga_interval", 5)
    )

    fun saveNtrip(profile: NtripProfile) {
        prefs.edit()
            .putString("ntrip_host", profile.host)
            .putInt("ntrip_port", profile.port)
            .putString("ntrip_mount", profile.mountPoint)
            .putString("ntrip_user", profile.username)
            .putString("ntrip_pass", profile.password)
            .putInt("ntrip_gga_interval", profile.ggaIntervalSeconds)
            .apply()
    }

    fun commandDelayMillis(): Long = prefs.getLong("command_delay", 250L)

    fun saveCommandDelayMillis(value: Long) {
        prefs.edit().putLong("command_delay", value.coerceIn(50L, 2_000L)).apply()
    }
}
